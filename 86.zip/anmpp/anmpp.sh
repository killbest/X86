fdir=/mnt/sdcard/PHP/anmpp
bbx=/system/xbin/busybox
$bbx echo "Install Anmpp ...."
$bbx tar -jxf $fdir/anmpp.tar.bz2 -C /data/data
$bbx mount -o remount,rw /system
$bbx echo "Install Gnulibc ...."
$bbx tar -jxf $fdir/gnulibc.tar.bz2 -C /system
$bbx echo "Install Console ...."
$bbx cp -r -f $fdir/anmpp /system/bin
$bbx chmod 0755 /system/bin/anmpp
$bbx chown root /system/bin/anmpp
$bbx chgrp root /system/bin/anmpp
$bbx mount -o remount,ro /system
$bbx echo "All Installation Complete ."
